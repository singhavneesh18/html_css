var users = ["Smith","John","Peter","Eliz","Kang"];

function showArray()
{
    console.log("Users are " + users);
}

function findUser()
{
    var uname = document.getElementById("txt-searchuser").value;

    var pos = users.indexOf(uname);

    if(pos==-1)
        console.log("User not found");
    else
        console.log("User found at position " + pos);
}

function sortInAsc()
{
    users.sort(function(a, b){return a-b});
    showArray();
}

employee = {
    'empcode':'E7723',
    'empname':'Eliz',
    'salary':'$1800',
    'expiriance':'3 years'
}

function showEmployee()
{
    console.log("Employee = " + JSON.stringify(employee,null,3));

    //Saperate Keys from Associate Key:Value Pairs
    var allkeys = Object.keys(employee);
    console.log("Only Keys = " + allkeys);

    var allvalues = Object.values(employee);
    console.log("Only values = " + allvalues);

    console.log("Reading Employee details using for loop");
    for(var key in employee)
    {
        console.log(`${key} => ${employee[key]}`);
    }
}


var products = [
    {id:'P9181',prodname:'mouse',price:'$50',qtys:3},
    {id:'P9182',prodname:'speaker',price:'$40',qtys:2},
    {id:'P9183',prodname:'pen drive',price:'$20',qtys:1},
    {id:'P9184',prodname:'RAM',price:'$80',qtys:8},
    {id:'P9185',prodname:'processor',price:'$70',qtys:11},
];

function showProducts()
{
    for(var item of products)
    {
        console.log(JSON.stringify(item,null,3));
    }
}


















