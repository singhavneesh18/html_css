function closeAlert()
{
    document.getElementById("ptag-answer").hidden=true;
}


function selectSkill(target)
{
    var ref = document.getElementById("ans");
    ref.innerHTML = `You Selected ${target.value} skill`;
}


var items = new Set();

function selectFeature(target)
{
    if(target.checked==true)
        items.add(target.value);
    else
        items.delete(target.value);

    var ref = document.getElementById("ans");
    ref.innerHTML = `You Selected ${Array.from(items)}`;    
}

function countCharacters(target)
{
    var total = target.value.length;
    document.getElementById("label-1").innerHTML = total;
}

function initialize()
{
    alert("HTML Contents loaded successfully");
}