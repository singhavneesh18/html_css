
function validate_user()
{
    var ref = document.getElementById("label-1");
    var uname = document.getElementById("txt-username").value;

    //username must contain minimum6 and maximum 13 characters
    //special symbols not allowed

    if(/^[a-zA-Z]+$/.test(uname) && uname.length>=6 && uname.length<=13)
    {
        ref.innerHTML="Valid";
    }
    else
    {
        ref.innerHTML="Invalid!"
    }
}

function validate_password()
{
    //password must contain minimum 8 characters
    //must contain minmum 1 Capital alphabate, 1 numeric digit and 1 symbol 
}



//https://regex101.com/