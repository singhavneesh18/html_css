function closeAlert()
{
    document.getElementById("ptag-answer").hidden=true;
}
