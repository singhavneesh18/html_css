
function closeAlert()
{
    document.getElementById("ptag-answer").hidden=true;
}

function addition()
{
    var x = Number(document.getElementById("num-x").value);
    var y = Number(document.getElementById("num-y").value);

    var ref = document.getElementById("ans");
    ref.innerHTML = `Addition of ${x} and ${y} is ${x+y}`;
}

function subtraction()
{
    var x = Number(document.getElementById("num-x").value);
    var y = Number(document.getElementById("num-y").value);

    var ref = document.getElementById("ans");
    ref.innerHTML = `Subtraction of ${x} and ${y} is ${x-y}`;   
}