//Example 1 
var x = 10;
var x = 20;
console.log("First var x = " + x); //10
console.log("Second var x = " + x); //20
//Example 2
var q = 20;
q = 99;
console.log("var q = " + q);
console.log("Reasignment to var q = " + q);
//Example 3
for (var i = 1; i <= 2; i++) {
    var e = i + 1;
}
console.log("var e outsid for loop = " + e);
//Example 4
function test() {
    var t = 10;
}
test();
console.log("var t outside function = " + t);
/*
1. Re-Declaration using var keyword is valid
2. you can Re-Assign values using var keyword
3. var is global/function scope variable. ie. even it is declared inside any block (if, for, else, while)
   still accessible outside the block
*/ 
