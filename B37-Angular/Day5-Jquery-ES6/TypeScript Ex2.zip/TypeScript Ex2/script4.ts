//Example 1

var t:number = 19;
let e:number = t; //copy of t saved in e (It is not a reference)

console.log("var t = " + t);
console.log("let e = " + e);

e=14;
console.log("after chamge, var t = " + t + "\t let e = " + e);

//Exmaple 2

let x1:number[] = [11,12];
let x2:number[] = x1;

x2[0] = 600; //not a copy of x1 ie. (It is reference variable)
console.log("x1 = " + x1);



