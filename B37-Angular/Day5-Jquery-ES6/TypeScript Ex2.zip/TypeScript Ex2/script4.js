//Example 1
var t = 19;
var e = t; //copy of t saved in e (It is not a reference)
console.log("var t = " + t);
console.log("let e = " + e);
e = 14;
console.log("after chamge, var t = " + t + "\t let e = " + e);
//Exmaple 2
var x1 = [11, 12];
var x2 = x1;
x2[0] = 600;
console.log("x1 = " + x1);
