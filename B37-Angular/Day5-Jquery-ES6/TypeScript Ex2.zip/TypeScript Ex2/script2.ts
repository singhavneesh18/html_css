//Example 4

function test()
{
    let t:number =100;
}

test();
console.log("outside function, t = " + t);


//Example 3

for(let i:number=1;i<=2;i++)
{
    let e:number=i+1;
}

//console.log("let e outside for loop = " + e);


//Example 2
let v:number = 1800;
v = 1900;

console.log("let v = " + v);
console.log("Re assignment v = " + v);



//Example 1
let r:number=100;
// let r:number=102;

console.log("variable let r = " + r);
console.log("variable let r (Redeclaration) = " + r);

/*
Note:
1. Re-Declaration using let keyword is invalid
2. Re-Assignment using let is valid
3. let keyword is block scope variable. ie. It is limited to block (if, else, while, for, function)
*/