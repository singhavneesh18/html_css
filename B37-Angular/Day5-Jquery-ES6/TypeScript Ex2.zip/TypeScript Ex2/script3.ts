//Example 4

function test()
{
    const e:number = 200;
}


console.log("outside function, const e = " + e);

//Example 3
for(let i:number=1;i<=2;i++)
{
    const t:number=14;
}

console.log("const t outside for loop = " + t);


//Example 2
const z:number = 100;
z=200;

console.log("Re-Assignment const z = " + z);

//Example 1
const x:number=100;
const x:number=200;

console.log("const x = " + x);


/*
Note:
1. Re-Declaration is not valid using const keyword
2. Re-Assignment also not valid using const keyword
3. const variable is a block scope variable.
*/