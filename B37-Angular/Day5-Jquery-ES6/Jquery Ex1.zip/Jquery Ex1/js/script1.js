
var products = [
    {id:'P9181',prodname:'mouse',price:'$50',qtys:3},
    {id:'P9182',prodname:'speaker',price:'$40',qtys:2},
    {id:'P9183',prodname:'pen drive',price:'$20',qtys:1},
    {id:'P9184',prodname:'RAM',price:'$80',qtys:8},
    {id:'P9185',prodname:'processor',price:'$70',qtys:11},
];


$(document).ready(function(){

    $("p").click(function(){
        console.log($(this).text());
    });

    $("#txt-username").keyup(function(){
        $("#label-1").text($(this).val().length);
    });

    //username=admin and password=123456
    $("#btn-login").click(function(){
        if($("#txt-username").val()=="admin" && $("#txt-password").val()=="123456")
        {
            alert("Login Successfull");
        }
        else
        {
            alert("username or password incorrect");
        }
    });


    $("#btn-products").click(function(){
        $("#tbody-1").text("");

        for(var item of products)
        {
            $("#tbody-1").append(`
                <tr>
                    <td>${item.id}</td>
                    <td>${item.prodname}</td>
                    <td>${item.price}</td>
                    <td>${item.qtys}</td>
                    <td></td>
                </tr>
            `);
        }
    });
});