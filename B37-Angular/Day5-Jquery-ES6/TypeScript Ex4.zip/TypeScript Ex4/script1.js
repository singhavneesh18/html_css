var x = [11, 14, 52, 52, 33, 52, 31, 54, 10, 49];
//Q1. update array x adding more 10 in each integer
for (var i = 0; i < x.length; i++) {
    x[i] = x[i] + 10;
}
//Q2. print following format of output from array x
//    {11:2, 14:5, 52:7, ...  so on}
var result = {};
for (var i = 0; i < x.length; i++) {
    var t = x[i]; //11
    var addn = 0;
    while (t != 0) {
        addn = addn + t % 10;
        t = Math.floor(t / 10);
    }
    result[x[i]] = addn;
}
console.log("formatted output : " + JSON.stringify(result));
//Q3. Filter and get only numbers which are greater than 25
var somenumbers = [];
for (var i = 0; i < x.length; i++) {
    if (x[i] > 25)
        somenumbers.push(x[i]);
}
console.log("Greater than 25 : " + somenumbers);
