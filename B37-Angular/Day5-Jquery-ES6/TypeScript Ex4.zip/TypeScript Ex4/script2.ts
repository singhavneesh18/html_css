var x:number[] = [11,14,52,52,33,52,31,54,10,49];

//Q1. update array x adding more 10 in each integer

let ans1 = x.map(item => item + 10);
console.log("Answer1 = " + ans1);

//Q2. print following format of output from array x
//    {11:2, 14:5, 52:7, ...  so on}

let ans2 = x.map((item,index)=>{
    let t=item;
    let addn = 0;
    while(t!=0)
    {
        addn = addn + (t%10);
        t = Math.floor(t/10);
    }

    return {[item]:addn};
});

console.log(ans2);


//Q3. Filter and get only numbers which are greater than 25
let ans3 = x.filter(item=>item>25);

console.log(ans3);


