var x = [11, 14, 52, 52, 33, 52, 31, 54, 10, 49];
//Q1. update array x adding more 10 in each integer
var ans1 = x.map(function (item) { return item + 10; });
console.log("Answer1 = " + ans1);
//Q2. print following format of output from array x
//    {11:2, 14:5, 52:7, ...  so on}
var ans2 = x.map(function (item, index) {
    var _a;
    var t = item;
    var addn = 0;
    while (t != 0) {
        addn = addn + (t % 10);
        t = Math.floor(t / 10);
    }
    return _a = {}, _a[item] = addn, _a;
});
console.log(ans2);
//Q3. Filter and get only numbers which are greater than 25
var ans3 = x.filter(function (item) { return item > 25; });
console.log(ans3);
