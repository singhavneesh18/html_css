//Demonstrate variables in typescript

var x:number = 19;
var username:string = "shrenik";
var result:boolean = true;
var z:number[] = [10,30,40];
var user:any = {
    'fname':'smith',
    'lname':'mathew',
    'age':30,
    'location':'UK'
}

console.log("x = " + x);
console.log("username = " + username);
console.log("result = " + result);
console.log("array z = " + z);
console.log("user object = " + user);

//How to compile typescript file? : tsc program_name.ts
//How to run typescript program? : node program_name.js
//Shortcut to open terminal : Ctrl + ~