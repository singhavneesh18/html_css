//Demonstrate variables in typescript
var x = 19;
var username = "shrenik";
var result = true;
var z = [10, 30, 40];
var user = {
    'fname': 'smith',
    'lname': 'mathew',
    'age': 30,
    'location': 'UK'
};
console.log("x = " + x);
console.log("username = " + username);
console.log("result = " + result);
console.log("array z = " + z);
console.log("user object = " + user);
//How to compile typescript file? : tsc program_name.ts
//How to run typescript program? : node program_name.js
