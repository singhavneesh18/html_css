function addition(a, b) {
    return a + b;
}
function subtraction(a, b) {
    return a - b;
}
function multiplication(a, b) {
    return a * b;
}
function division(a, b) {
    return a / b;
}
var addn = addition(10, 8);
console.log("Addition = " + addn);
var subt = subtraction(10, 8);
console.log("Subtraction = " + subt);
var mult = multiplication(10, 8);
console.log("Multiplication = " + mult);
var divn = division(10, 8);
console.log("Division = " + divn);
