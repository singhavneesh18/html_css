function addition(a:number, b:number)
{
    return a+b;
}

function subtraction(a:number, b:number)
{
    return a-b;
}

function multiplication(a:number, b:number)
{
    return a*b;
}

function division(a:number, b:number)
{
    return a/b;
}

let addn = addition(10, 8);
console.log("Addition = " + addn);

let subt = subtraction(10, 8);
console.log("Subtraction = " + subt);

let mult = multiplication(10, 8);
console.log("Multiplication = " + mult);

let divn = division(10, 8);
console.log("Division = " + divn);

