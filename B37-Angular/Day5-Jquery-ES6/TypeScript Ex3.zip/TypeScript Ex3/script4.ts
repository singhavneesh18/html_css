let addition = (a:number, b:number) => a+b;

let subtraction = (a:number, b:number) => a-b;

let multiplication = (a:number, b:number) => a*b;

let division = (a:number, b:number) => a/b;



let addn = addition(10, 8);
console.log("Addition = " + addn);

let subt = subtraction(10, 8);
console.log("Subtraction = " + subt);

let mult = multiplication(10, 8);
console.log("Multiplication = " + mult);

let divn = division(10, 8);
console.log("Division = " + divn);

