let addition = function(a:number, b:number)
{
    return a+b;
}

let subtraction = function(a:number, b:number)
{
    return a-b;
}

let multiplication = function(a:number, b:number)
{
    return a*b;
}

let division = function(a:number, b:number)
{
    return a/b;
}

let addn = addition(10, 8);
console.log("Addition = " + addn);

let subt = subtraction(10, 8);
console.log("Subtraction = " + subt);

let mult = multiplication(10, 8);
console.log("Multiplication = " + mult);

let divn = division(10, 8);
console.log("Division = " + divn);

