

let addition = (a:number, b:number) => {
    return a + b;
}

let subtraction = (a:number, b:number) => {
    return a-b;
}

let multiplication = (a:number, b:number) => {
    return a*b;
}

export {addition, subtraction, multiplication};