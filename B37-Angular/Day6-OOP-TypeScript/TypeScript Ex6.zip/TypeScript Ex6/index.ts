import {addition, subtraction, multiplication} from './script2';

let ans1 = addition(10, 20);
let ans2 = subtraction(10, 4);
let ans3 = multiplication(18, 4);

console.log("Addition = " + ans1);
console.log("Subtraction = " + ans2);
console.log("Multiplication = " + ans3);

let call = (c1, c2, c3) => {
    return {ans1:c1(18, 3), ans2:c2(13,4), ans3:c3(8,2)};
}

let response = call(addition, subtraction, multiplication);

console.log(response);

