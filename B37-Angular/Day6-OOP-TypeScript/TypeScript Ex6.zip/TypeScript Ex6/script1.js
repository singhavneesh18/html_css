var abc = function () {
    console.log("Hello World");
};
var x = abc;
x();
