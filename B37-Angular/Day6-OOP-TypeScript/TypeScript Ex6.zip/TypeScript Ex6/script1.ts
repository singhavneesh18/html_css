

let abc = () => {
    console.log("Hello World");
}

let x = abc;

x();

