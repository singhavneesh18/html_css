"use strict";
exports.__esModule = true;
var axios_1 = require("axios");
var getAllEmployees = function () {
    var pobj = axios_1["default"].get("http://localhost:3000/employees/");
    pobj.then(function (response) {
        console.log(response.data);
    });
    pobj["catch"](function (error) {
        console.log(error);
    });
    console.log("Promise Object = " + pobj);
};
var saveEmployee = function (empObj) {
    var pobj = axios_1["default"].post("http://localhost:3000/employees/", empObj);
    pobj.then(function (response) {
        console.log(response.data);
    });
    pobj.then(function (error) {
        console.log(error);
    });
};
// getAllEmployees();
saveEmployee({ "id": "E019", "fname": "Jinesh", "lname": "Patel", "salary": "Rs.22000", "expirience": "2 years" });
