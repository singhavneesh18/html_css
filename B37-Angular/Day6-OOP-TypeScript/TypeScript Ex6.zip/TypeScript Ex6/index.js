"use strict";
exports.__esModule = true;
var script2_1 = require("./script2");
var ans1 = (0, script2_1.addition)(10, 20);
var ans2 = (0, script2_1.subtraction)(10, 4);
var ans3 = (0, script2_1.multiplication)(18, 4);
console.log("Addition = " + ans1);
console.log("Subtraction = " + ans2);
console.log("Multiplication = " + ans3);
var call = function (c1, c2, c3) {
    return { ans1: c1(18, 3), ans2: c2(13, 4), ans3: c3(8, 2) };
};
var response = call(script2_1.addition, script2_1.subtraction, script2_1.multiplication);
console.log(response);
