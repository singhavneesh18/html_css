"use strict";
exports.__esModule = true;
exports.multiplication = exports.subtraction = exports.addition = void 0;
var addition = function (a, b) {
    return a + b;
};
exports.addition = addition;
var subtraction = function (a, b) {
    return a - b;
};
exports.subtraction = subtraction;
var multiplication = function (a, b) {
    return a * b;
};
exports.multiplication = multiplication;
