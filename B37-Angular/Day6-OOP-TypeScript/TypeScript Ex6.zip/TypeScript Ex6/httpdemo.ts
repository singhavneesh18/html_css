import axios from 'axios';

let getAllEmployees = () => {
    let pobj = axios.get("http://localhost:3000/employees/");

    pobj.then((response)=>{
        console.log(response.data);
    });

    pobj.catch((error)=>{
        console.log(error);
    });

    console.log("Promise Object = " + pobj);
}


let saveEmployee = (empObj) => {
    let pobj = axios.post("http://localhost:3000/employees/", empObj);

    pobj.then((response)=>{
        console.log(response.data);
    });

    pobj.then((error)=>{
        console.log(error);
    });
}

// getAllEmployees();
saveEmployee({"id":"E019", "fname":"Jinesh", "lname":"Patel", "salary":"Rs.22000", "expirience":"2 years"});