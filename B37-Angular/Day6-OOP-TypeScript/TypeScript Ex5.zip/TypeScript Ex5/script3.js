var Product = /** @class */ (function () {
    function Product(prodcode, prodname, price) {
        if (prodcode === void 0) { prodcode = 0; }
        if (prodname === void 0) { prodname = "NA"; }
        if (price === void 0) { price = 0.0; }
        this.prodcode = prodcode;
        this.prodname = prodname;
        this.price = price;
    }
    return Product;
}());
var p1 = new Product(1801, "Mouse", 1900.00);
var p2 = new Product(1945, "Keyboard", 1500.00);
var p3 = new Product(1730, "RAM", 1700.00);
var p4 = new Product();
console.log(p1);
console.log(p2);
console.log(p3);
console.log("First Product Name = " + p1.prodname);
