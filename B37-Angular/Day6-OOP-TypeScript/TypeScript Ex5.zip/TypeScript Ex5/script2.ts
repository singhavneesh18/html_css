
class Product
{
    public prodcode:number;
    public prodname:string;
    public price:number;

    constructor(prodcode:number, prodname:string, price:number)
    {
        this.prodcode = prodcode;
        this.prodname = prodname;
        this.price = price;
    }
}

let p1 = new Product(1801, "Mouse", 1900.00);
let p2 = new Product(1945, "Keyboard", 1500.00);
let p3 = new Product(1730, "RAM", 1700.00);

console.log(p1);
console.log(p2);
console.log(p3);