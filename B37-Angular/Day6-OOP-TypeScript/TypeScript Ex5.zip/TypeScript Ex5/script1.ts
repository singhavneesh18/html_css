class Employee
{
    public empcode:number;
    public empname:string;
    public salary:number;

    public addEmployee(empcode:number, empname:string, salary:number):any{
        this.empcode = empcode;
        this.empname = empname;
        this.salary = salary;
    }
}

let e1 = new Employee();
e1.addEmployee(19001, "Smith", 18000.00);

let e2 = new Employee();
e2.addEmployee(19002, "John", 45000.00);

let e3 = new Employee();
e3.addEmployee(19004, "Peter", 50000.00);

console.log(e1);
console.log(e2);
console.log(e3);
