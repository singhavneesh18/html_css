
class Product
{
    constructor(public prodcode:number=0, public prodname:string="NA", public price:number=0.0)
    {  }
}

let p1 = new Product(1801, "Mouse", 1900.00);
let p2 = new Product(1945, "Keyboard", 1500.00);
let p3 = new Product(1730, "RAM", 1700.00);
let p4 = new Product();

console.log(p1);
console.log(p2);
console.log(p3);

console.log("First Product Name = " + p1.prodname);