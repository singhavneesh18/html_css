class User{
    public constructor(
        public fname:string,
        public lname:string,
        public username:string,
        public password:string,
        public age:number
    ){}
}

let signUp = (profile:User) => {
    console.log("First Name = " + profile.fname);
    console.log("Last Name = " + profile.lname);
    console.log("Username = " + profile.username);
    console.log("Password = " + profile.password);
    console.log("Age = " + profile.age);
}

// signUp(18763774771, "MH771AT8842", "smith77india", "Admin@123", "smith");
signUp(new User("18763774771", "MH771AT8842", "smith77india", "Admin@123", 89));



