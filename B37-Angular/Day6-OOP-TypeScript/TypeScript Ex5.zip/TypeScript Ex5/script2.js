var Product = /** @class */ (function () {
    function Product(prodcode, prodname, price) {
        this.prodcode = prodcode;
        this.prodname = prodname;
        this.price = price;
    }
    return Product;
}());
var p1 = new Product(1801, "Mouse", 1900.00);
var p2 = new Product(1945, "Keyboard", 1500.00);
var p3 = new Product(1730, "RAM", 1700.00);
console.log(p1);
console.log(p2);
console.log(p3);
