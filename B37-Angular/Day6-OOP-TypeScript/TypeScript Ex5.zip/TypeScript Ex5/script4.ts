

class Animal
{
    public move()
    {
        console.log("Animal not moving....!");
    }
}

    class Bird extends Animal{
        public  move():any{
            console.log("Bird is Flying");
        }
    }

    class Fish extends Animal{
        public move():any{
            console.log("Fish is Swimming");
        }
    }

    class Dog extends Animal{
        public move():any{
            console.log("Dog is Running");
        }
    }

let a:Animal;

a = new Animal();
a.move();

a = new Bird();
a.move();

a = new Fish();
a.move();