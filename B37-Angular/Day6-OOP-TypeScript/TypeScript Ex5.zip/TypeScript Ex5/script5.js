var signUp = function (fname, lname, username, password, age) {
    console.log("First Name = " + fname);
    console.log("Last Name = " + lname);
    console.log("Username = " + username);
    console.log("Password = " + password);
    console.log("Age = " + age);
};
// signUp(18763774771, "MH771AT8842", "smith77india", "Admin@123", "smith");
signUp("18763774771", "MH771AT8842", "smith77india", "Admin@123", 89);
