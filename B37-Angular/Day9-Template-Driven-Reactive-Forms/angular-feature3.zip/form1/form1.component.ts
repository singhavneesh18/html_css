import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form1',
  templateUrl: './form1.component.html',
  styleUrls: ['./form1.component.css']
})
export class Form1Component implements OnInit {

  public cities:any = {1:'Mumbai',2:'Bangalore',3:'Pune'};

  constructor() { 
    for(const [key, value] of Object.entries(this.cities))
    {
      console.log(key + "->" + value);
    }
  }

  ngOnInit(): void {
  }

  public createUser = (uform:any) => {
    uform.value['contact'] = {'whatsapp':'9988998899', 'home':'00000000'};
    console.log(uform.value);
  }
}
