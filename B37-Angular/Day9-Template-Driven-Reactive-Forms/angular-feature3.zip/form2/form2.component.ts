import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-form2',
  templateUrl: './form2.component.html',
  styleUrls: ['./form2.component.css']
})
export class Form2Component implements OnInit {

   public userRegistration = new FormGroup({
    personalinfo:new FormGroup({
       username:new FormControl("Shrenik"),
       password:new FormControl("Admin@123"),
       confirmpwd:new FormControl("Admin@123")
     }),

     emailid:new FormControl(""),

     address:new FormGroup({
       street:new FormControl(""),
       city:new FormControl(""),
       zipcode:new FormControl("")
     })

   });

  constructor() { }

  ngOnInit(): void {
  }

  public createUser(){
    console.log(JSON.stringify(this.userRegistration.value, null, 3));
  }

}
